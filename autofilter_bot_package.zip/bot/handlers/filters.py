# Handles filtering logic
