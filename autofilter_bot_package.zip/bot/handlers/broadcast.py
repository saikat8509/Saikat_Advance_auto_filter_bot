# Broadcast logic
