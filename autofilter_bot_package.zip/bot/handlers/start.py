# Handles /start and command routing
