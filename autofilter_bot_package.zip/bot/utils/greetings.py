# Greeting message manager
