# Shortener/token verify logic
