# IMDb fetch logic
