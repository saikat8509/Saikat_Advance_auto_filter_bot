# Full config with environment support
